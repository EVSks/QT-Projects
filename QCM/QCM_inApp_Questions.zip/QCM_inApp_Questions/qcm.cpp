#include "qcm.h"

/*QCM::QCM()
{

}*/
